<?php 
  $answerA = 4 + 5;
  $answerB = 4 * 2;
  $answerC = 12 - 5;
  $answerD = 12 / 2;
?>
<!DOCTYPE html>
<html>
<head>
  <title>TEST</title>
</head>
<body>
<?php 
  echo $answerA; //prints 9
  echo $answerB; //prints 8
  echo $answerC; //prints 7
  echo $answerD; //prints 6
?>
</body>
</html>
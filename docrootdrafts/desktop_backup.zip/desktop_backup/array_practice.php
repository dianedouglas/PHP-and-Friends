<?php 
$groceries = array("eggs", "milk", "bread");
$list = "";
foreach ($groceries as $purchase) {
  $list .= "<h3>" . $purchase . "</h3>";
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Array Practice</title>
</head>
<body>
  <h1>My Grocery List</h1>
  <?php echo $list; ?>
</body>
</html>


<?php

$my_descriptive_variable = 3;

class MyClass
{
    function testTwoNumbers($first_number, $second_number)
    {
        while ($this_is_true) {
        # code...
        }

        if ($first_number > $second_number || $first_number < 0) {
            // if body 
        } elseif ($first_number > $third_number) {
            // elseif
        } else {
            // else body
        }

        for ($i=0; $i < 3; $i++) { 
            echo "Hi!";
        }

        return 1;
    }
}

?>
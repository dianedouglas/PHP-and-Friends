<?php 

function check_age($user_age){
  if ($user_age > 21) {
    return "You can drink!";
  }
  else {
    return "No drinks for you!";
  }
}

if ($lindsey == "able to drive") {
  go_to_beach($friends);
} 
elseif ($buses_are_running == true) {
  go_to_beach($friends);
}
else {
  watch_movies($friends);
}

?>
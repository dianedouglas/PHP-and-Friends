<?php 

function testConditions($input){
    if !(5 > 6) {
        echo "this is true!";
    } else {
        echo "this is false!";
    }
}

?>